import React from "react";
import "./EnergySavingExpertise.css";

const EnergySavingExpertise = () => {
  return (
    <div className="energy-saving-container">
      <h1>Energy Saving Expertise – Process & Pump Integrated Approach</h1>

      <p>
        As a Senior Energy Auditor with extensive experience in pumping system
        energy audits and retrofit implementations, I can confidently say that
        true energy optimization is achieved only when one understands both the
        pump and the process it serves. At Shaft & Seal, this holistic
        understanding is what defines our energy-saving expertise.
      </p>

      <div className="energy-saving-highlight">
        Most audits focus solely on the pump performance – but the real savings
        lie at the intersection of <strong>system demand, process behavior, and pump characteristics</strong>.
      </div>

      <p>
        Our certified BEE Energy Auditors are trained to interpret process flow logic, system curve dynamics, and pump efficiency simultaneously.
      </p>

      <h3>Here’s how our expertise stands out:</h3>

      <h4>1. Process Understanding:</h4>
      <ul>
        <li>We analyze the process requirements – whether continuous or batch, constant or variable flow.</li>
        <li>We identify where process overdesign leads to unnecessary pressure drops or overpumping.</li>
        <li>We factor in tank levels, control valve behavior, and pipe routing losses.</li>
      </ul>

      <h4>2. Pump Performance Analysis:</h4>
      <ul>
        <li>We measure real-time flow, head, and kW using ultrasonic flow meters, pressure gauges, and energy analyzers.</li>
        <li>We plot actual operating points and compare them to the Best Efficiency Point (BEP).</li>
        <li>We identify opportunities for <strong>impeller trimming, resizing, or VFD control</strong>.</li>
      </ul>

      <h4>3. Integrated Optimization:</h4>
      <ul>
        <li>We create a detailed system curve and match it to optimized pump selections.</li>
        <li>We re-engineer pump internals when necessary to match new duty points.</li>
        <li>We help eliminate throttling losses and increase system responsiveness.</li>
      </ul>

      <h4>4. Post-Audit Implementation:</h4>
      <ul>
        <li>We don’t stop at reports – we retrofit, upgrade, and commission.</li>
        <li>Our in-house machining, balancing, and assembly teams ensure precision execution.</li>
        <li>We validate savings through post-implementation measurement and verification.</li>
      </ul>

      <p>
        Clients across power plants, refineries, paper mills, and chemical
        factories have trusted us to reduce their energy consumption by <strong>25% to 40%</strong>, enhance reliability, and improve process stability.
      </p>

      <p>
        Because we understand both <strong>hydraulic machinery and process behavior</strong>, we don’t just save energy — we improve systems.
      </p>

      <div className="energy-saving-footer">
        That’s the Shaft & Seal advantage.
      </div>
    </div>
  );
};

export default EnergySavingExpertise;
