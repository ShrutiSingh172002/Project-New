import React from "react";
import "./SalesContainer.css";
import machineImage from "./machineImage.png";
import wrenchIcon from "./icons/wrench.png";
import boxIcon from "./icons/box.png";
import boltIcon from "./icons/bolt.png";
import gearIcon from "./icons/gear.png";
import pumpIcon from "./icons/pump.png";
import auditIcon from "./icons/audit.png";
import logoImage from "./logo.jpg";
import { useNavigate } from "react-router-dom";
const SalesContainer = () => {
   const navigate = useNavigate();
  return (
    <div className="sales-container">
      {/* Navbar */}
      <div className="sales-navbar">
        <div className="sales-logo">
          <img src={logoImage} alt="Company Logo" />
        </div>
        <div className="sales-nav-links">
          <a href="#">Home</a>
          <a href="#">Contact Us</a>
          <a href="#">Login</a>
        </div>
      </div>

      {/* Header */}
      <div className="sales-header-section">
        <div className="sales-text-block">
          <h1>
            Engineering
            <br />
            Reliability.
            <br />
            Minimizing Inventory.
            <br />
            Maximizing Efficiency.
          </h1>
          <p>
            Shaft & Seal helps industries unlock energy savings, restore pump
            performance, and eliminate downtime.
          </p>
        </div>
        <div className="sales-image-block">
          <img src={machineImage} alt="Pump Machine" />
        </div>
      </div>

      {/* Why Choose Us */}
      <div className="sales-why-choose">
        <h2>Why Choose Shaft & Seal?</h2>
        <div className="sales-features">
          <div className="sales-feature"onClick={() => navigate("/reliable-rebuilds")}>
            <img src={wrenchIcon} alt="Wrench Icon" className="icon" />
            <h3>Reliable Rebuilds</h3>
            <p>
              Reverse engineered to OEM Standards or better - ensuring long-term
              performance.
            </p>
          </div>
          <div className="sales-feature">
            <img src={boxIcon} alt="Box Icon" className="icon" />
            <h3>Inventory Minimization</h3>
            <p>
              We help reduce spare parts holding by custom engineering
              interchangeable components.
            </p>
          </div>
          <div className="sales-feature"  onClick={() => navigate("/energy-saving-expertise")}>
            <img src={boltIcon} alt="Energy Icon" className="icon" />
            <h3>Energy-Saving Expertise</h3>
            <p>
              Optimized hydraulics for reduced power bids – especially on boiler
              food-systems.
            </p>
          </div>
        </div>
      </div>

      {/* Core Services */}
      <div className="sales-core-services">
        <h2>Our Core Services</h2>
        <div className="sales-services">
          <div className="sales-service"onClick={() => navigate("/reverse-engineering")}>
            <img src={gearIcon} alt="Gear Icon" className="icon" />
            <p>Reverse Engineering</p>
          </div>
          <div className="sales-service" onClick={() => navigate("/precision-pump-repair")}>
            <img src={pumpIcon} alt="Pump Icon" className="icon" />
            <p>Precision Pump Repair</p>
          </div>
          <div className="sales-service">
            <img src={auditIcon} alt="Audit Icon" className="icon" />
            <p>Energy Audit</p>
          </div>
          <div
            className="sales-service"
          onClick={() => navigate("/energy-saving")}
          >
            <img src={boltIcon} alt="Energy Icon" className="icon" />
            <p>Energy-Saving Expertise</p>
          </div>
        </div>
      </div>

      {/* Strategy Section */}
      <div className="sales-strategy-section">
        <div className="sales-strategy-container">
          {/* Left: Triangle + heading */}
          <div className="sales-triangle-block">
            <h2>
              From Downtime to Uptime:
              <br />
              Our Reliability Strategy
            </h2>
            <svg viewBox="0 0 200 200" className="sales-triangle-svg">
              <polygon
                points="100,0 0,180 200,180"
                className="triangle-outline"
              />
              <line x1="60" y1="70" x2="140" y2="70" className="divider" />
              <line x1="25" y1="125" x2="175" y2="125" className="divider" />
              <text x="100" y="55" className="triangle-label">
                Redesign
              </text>
              <text x="100" y="105" className="triangle-label">
                Redesign
              </text>
              <text x="100" y="160" className="triangle-label">
                Root Cause Analysis
              </text>
            </svg>
          </div>

          {/* Right: Points + Button */}
          <div className="sales-strategy-content">
            <ul className="sales-strategy-points">
              <li>MTBF (Incremental TM)</li>
              <li>Interchangeable spares to cover multiple pump types</li>
              <li>Modular design for on-demand manufacturing</li>
            </ul>
            <button className="sales-case-studies-btn">See Case Studies</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesContainer;
