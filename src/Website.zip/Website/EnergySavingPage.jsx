import React from "react";
import "./EnergySavingPage.css";

const EnergySavingPage = () => {
  return (
    <div className="energy-saving-page">
      <h1>Energy Saving in Pumping Systems</h1>

      <p>
        As a Senior Energy Auditor specializing in pumping systems, I have encountered
        numerous industrial setups where inefficiencies in pump operation account for
        a significant portion of wasted energy. Proper pump system assessment and
        optimization can yield energy savings ranging from <strong>20% to 40%</strong>,
        leading to substantial cost reductions and reduced carbon emissions.
      </p>

      <h3>Common Issues Identified</h3>
      <ul>
        <li>Pumps operating far from their Best Efficiency Point (BEP)</li>
        <li>Oversized pumps running with throttled valves</li>
        <li>Lack of variable frequency drives (VFDs) to match variable demand</li>
        <li>Aging and worn-out impellers or motors</li>
        <li>Incorrectly sized piping or poorly designed layouts</li>
      </ul>

      <h3>Our Energy Audit Process</h3>
      <ul>
        <li>Recording real-time flow, head, and power consumption</li>
        <li>Plotting the system curve vs. pump’s operating curve</li>
        <li>Identifying mismatch and inefficiency zones</li>
        <li>Recommending actions: impeller trimming, resizing, VFD installation</li>
      </ul>

      <p>
        By aligning the pump curve with the system curve near the BEP, energy
        consumption and mechanical wear are significantly reduced.
      </p>

      <h3>Outcomes</h3>
      <ul>
        <li><strong>25%–35%</strong> reduction in energy consumption</li>
        <li>Lower maintenance and downtime</li>
        <li>Extended pump and motor life</li>
        <li>Improved reliability and sustainability</li>
      </ul>

      <p>
        At <strong>Shaft & Seal</strong>, our certified BEE Energy Auditors help
        industries unlock savings through data-driven audits and engineered interventions.
      </p>
    </div>
  );
};

export default EnergySavingPage;
