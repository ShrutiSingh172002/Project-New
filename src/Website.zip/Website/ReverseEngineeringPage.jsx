import React from "react";
import "./ReverseEngineeringPage.css";

const ReverseEngineeringPage = () => {
  return (
    <div className="reverse-engineering-page">
      <h1>Reverse Engineering of Pumping Systems</h1>

      <ol>
        <li><strong>Initial Assessment & Dismantling:</strong> Preliminary inspection, dismantling, and documentation.</li>
        <li><strong>Degreasing & Cleaning:</strong> Chemical and ultrasonic cleaning.</li>
        <li><strong>3D Scanning & Measurement:</strong> CMM/laser scanning, precision measurement.</li>
        <li><strong>CAD Drawing Preparation:</strong> 3D modeling with GD&T and tolerances.</li>
        <li><strong>Drawing Review & Verification:</strong> Physical verification, simulations.</li>
        <li><strong>Pattern Making:</strong> Wood and aluminum patterns.</li>
        <li><strong>Metal Casting:</strong> WCB/CI/CA6NM casting with sand/shell molding.</li>
        <li><strong>Shot Blasting & Heat Treatment:</strong> Material conditioning based on grade.</li>
        <li><strong>Material Testing:</strong> Spectro, hardness, tensile, UT/DPT testing.</li>
        <li><strong>Machining:</strong> Rough + final machining, lapping & polishing.</li>
        <li><strong>Rotor Balancing:</strong> Dynamic balancing as per ISO.</li>
        <li><strong>Clearance Checks:</strong> API-standard tolerances and clearances.</li>
        <li><strong>Pump Assembly:</strong> Seals, bearings, torquing, preload.</li>
        <li><strong>Hydrostatic Test:</strong> 150% pressure test with zero leakage.</li>
        <li><strong>Painting & Finishing:</strong> Epoxy, PU coatings.</li>
        <li><strong>Dispatch & Site Fitment:</strong> Fitment, alignment, trial run, and handover.</li>
      </ol>
    </div>
  );
};

export default ReverseEngineeringPage;
