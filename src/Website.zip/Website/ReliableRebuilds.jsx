import React from "react";
import "./ReliableRebuilds.css";

const ReliableRebuilds = () => {
  return (
    <div className="reliable-rebuilds-container">
      <h1>From Downtime to Uptime: Shaft & Seal’s Reliability Strategy</h1>

      <p>
        As a reliability engineering expert at Shaft & Seal, our goal is to systematically eliminate pump failures and increase uptime using a structured, data-driven strategy. Our approach integrates condition-based analysis, engineering redesign, and modular manufacturing, all aligned with international standards such as API 610, ISO 14224, and ISO 10816.
      </p>

      <h3>Our strategy follows a 3-tier model:</h3>

      <h4>1. Root Cause Analysis (RCA)</h4>
      <ul>
        <li>We conduct detailed RCAs using tools like the 5 Whys, Fault Tree Analysis, and FMEA.</li>
        <li>Observations from failed pump components are documented with photographic and dimensional evidence.</li>
        <li>Process conditions, such as cavitation, thermal shock, or dry running, are analyzed using real-time data logging.</li>
        <li>We redesign systems based on root cause insights rather than replacing parts blindly.</li>
      </ul>

      <h4>2. Redesign for Reliability</h4>
      <ul>
        <li>Corrective design changes based on RCA:</li>
        <ul>
          <li>Impeller vane profile modification to address hydraulic imbalance.</li>
          <li>Bearing housing redesign for better alignment and lubrication.</li>
          <li>Shaft material upgrade to increase fatigue strength.</li>
          <li>Seal housing upgrades for better tolerance to temperature/pressure variations.</li>
        </ul>
        <li>Simulations in CAD/CAE to validate critical clearances, balance, and fits.</li>
      </ul>

      <h4>3. Modular Manufacturing</h4>
      <ul>
        <li>Designing interchangeable parts that serve multiple pump types across a plant or fleet.</li>
        <li>Reduces spare SKUs and enhances spare part readiness.</li>
        <li>Use of CNC-machined aluminum patterns and rapid casting to produce high-quality components in days, not weeks.</li>
        <li>Enables on-demand part production aligned with predictive maintenance insights.</li>
      </ul>

      <h3>Additional Focus Areas:</h3>
      <ul>
        <li>MTBF Tracking to validate improvement post-implementation.</li>
        <li>ISO-Certified Processes for global reliability standards compliance.</li>
        <li>Digital Twin Capability for simulation and future failure prevention.</li>
        <li>Field Trials & Monitoring, including hydro-testing at 150% design pressure, vibration, and performance monitoring.</li>
      </ul>

      <p>
        This layered reliability approach reduces unplanned shutdowns, optimizes operational cost, and improves equipment lifecycle.
      </p>

      <div className="reliable-rebuilds-footer">
        With Shaft & Seal, you don’t just fix pumps — you future-proof them.
      </div>
    </div>
  );
};

export default ReliableRebuilds;
