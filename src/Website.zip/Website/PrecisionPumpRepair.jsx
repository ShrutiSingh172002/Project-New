import React from "react";
import "./PrecisionPumpRepair.css";

const PrecisionPumpRepair = () => {
  return (
    <div className="precision-pump-container">
      <h1>Precision Pump Repair Process</h1>

      <p>
        As a Senior Pump Specialist, I present the comprehensive process of precision pump repair – a step-by-step methodology followed to restore critical pump systems to peak performance and reliability.
      </p>

      <h3>1. Receipt of Pump</h3>
      <ul>
        <li>Pump is received at the service center or workshop and logged with photographs.</li>
        <li>Unique job number is assigned for tracking and traceability.</li>
      </ul>

      <h3>2. Cleaning & Initial Inspection</h3>
      <ul>
        <li>External surfaces cleaned with degreasing solvents and pressure washing.</li>
        <li>Visual inspection for cracks, deformation, or corrosion.</li>
      </ul>

      <h3>3. Marking of Parts for Assembly</h3>
      <ul>
        <li>All components marked with serial numbers or color codes for proper reassembly.</li>
        <li>Orientation marks added to casing, impeller, wear rings, and diffusers.</li>
      </ul>

      <h3>4. Dismantling of Pump</h3>
      <ul>
        <li>Stage-by-stage dismantling using specialized tools to prevent damage.</li>
        <li>Observations documented, especially unusual wear or assembly deviations.</li>
      </ul>

      <h3>5. Identifying Damaged Parts</h3>
      <ul>
        <li>Inspection for wear, cracks, pitting, or corrosion.</li>
        <li>Evaluation of impellers, shafts, sleeves, wear rings, bushings, and seals for replacement or refurbishment.</li>
      </ul>

      <h3>6. Commercial Proposal to Customer</h3>
      <ul>
        <li>Service report and damage assessment prepared with costs, timelines, and warranty.</li>
        <li>Optional upgrades or modifications recommended.</li>
      </ul>

      <h3>7. Dimensional & Metallurgical Verification</h3>
      <ul>
        <li>Critical dimensions measured; hardness testing and metallurgical analysis performed.</li>
        <li>Comparison against OEM drawings or standards.</li>
      </ul>

      <h3>8. Sourcing or Rebuilding of Parts</h3>
      <ul>
        <li>Components sourced from OEMs or rebuilt in-house using reverse engineering.</li>
        <li>Reconditioning with welding, grinding, or coating; precision machining and balancing.</li>
      </ul>

      <h3>9. Rotor Assembly & Balancing</h3>
      <ul>
        <li>Rotor assembled and dynamically balanced to ISO Grade 2.5 to minimize vibration.</li>
      </ul>

      <h3>10. Clearance & Tolerance Maintenance</h3>
      <ul>
        <li>Rotating-to-stationary clearances checked per API 610 or OEM specs.</li>
        <li>Axial float, shaft end-play, and bearing fits precisely controlled.</li>
      </ul>

      <h3>11. Reassembly of Pump</h3>
      <ul>
        <li>Reassembled in a clean environment with new bearings, seals, and O-rings.</li>
        <li>Torque settings applied as per specifications.</li>
      </ul>

      <h3>12. Hydrostatic Testing</h3>
      <ul>
        <li>Pump hydro-tested at 150% maximum working pressure, observed for leakage.</li>
        <li>Test certificates generated and documented.</li>
      </ul>

      <h3>13. Final Painting & Preservation</h3>
      <ul>
        <li>Pump cleaned and painted with corrosion-resistant paint; shaft surfaces coated with rust preventive oil.</li>
      </ul>

      <h3>14. Packaging & Dispatch</h3>
      <ul>
        <li>Packed with moisture-proof wrapping, mounted on treated pallets, ports sealed with shipping documents included.</li>
      </ul>

      <h3>15. Final Site Trial</h3>
      <ul>
        <li>Optional commissioning and alignment support provided.</li>
        <li>Trial run performed with flow, pressure, vibration, temperature, and noise monitoring.</li>
        <li>Handover with full documentation and warranty activation.</li>
      </ul>

      <p>
        This rigorous, detail-oriented repair process ensures that every repaired pump from Shaft & Seal operates as reliably as a new unit – minimizing downtime and extending lifecycle performance.
      </p>
    </div>
  );
};

export default PrecisionPumpRepair;
